﻿namespace sortings
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lArraySize = new Label();
            tbArraySize = new TextBox();
            bGenerate = new Button();
            bSort = new Button();
            rtbResult = new RichTextBox();
            lResult = new Label();
            rbPancake = new RadioButton();
            rbInsert = new RadioButton();
            rbSelect = new RadioButton();
            gpSortTypes = new GroupBox();
            heap = new Button();
            tim = new Button();
            pancake = new Button();
            lbSortType = new Label();
            progressBar = new ProgressBar();
            lbPercent = new Label();
            backgroundSorting = new System.ComponentModel.BackgroundWorker();
            steps = new Button();
            rtArray = new RichTextBox();
            ttPancake = new ToolTip(components);
            ttTim = new ToolTip(components);
            ttHeap = new ToolTip(components);
            btCompare = new Button();
            gpSortTypes.SuspendLayout();
            SuspendLayout();
            // 
            // lArraySize
            // 
            lArraySize.AutoSize = true;
            lArraySize.Location = new Point(44, 28);
            lArraySize.Name = "lArraySize";
            lArraySize.Size = new Size(125, 20);
            lArraySize.TabIndex = 0;
            lArraySize.Text = "Размер массива:";
            // 
            // tbArraySize
            // 
            tbArraySize.BackColor = SystemColors.Control;
            tbArraySize.Location = new Point(175, 25);
            tbArraySize.Name = "tbArraySize";
            tbArraySize.Size = new Size(75, 27);
            tbArraySize.TabIndex = 1;
            // 
            // bGenerate
            // 
            bGenerate.BackColor = Color.CadetBlue;
            bGenerate.Location = new Point(44, 71);
            bGenerate.Name = "bGenerate";
            bGenerate.Size = new Size(127, 29);
            bGenerate.TabIndex = 2;
            bGenerate.Text = "Сгенерировать";
            bGenerate.UseVisualStyleBackColor = false;
            bGenerate.Click += bGenerate_Click_1;
            // 
            // bSort
            // 
            bSort.BackColor = Color.CadetBlue;
            bSort.Location = new Point(729, 176);
            bSort.Name = "bSort";
            bSort.Size = new Size(139, 29);
            bSort.TabIndex = 4;
            bSort.Text = "Отсортировать";
            bSort.UseVisualStyleBackColor = false;
            bSort.Click += bSort_Click;
            // 
            // rtbResult
            // 
            rtbResult.Location = new Point(478, 348);
            rtbResult.Name = "rtbResult";
            rtbResult.ReadOnly = true;
            rtbResult.Size = new Size(694, 114);
            rtbResult.TabIndex = 5;
            rtbResult.Text = "";
            rtbResult.TextChanged += rtbResult_TextChanged;
            // 
            // lResult
            // 
            lResult.AutoSize = true;
            lResult.Location = new Point(478, 318);
            lResult.Name = "lResult";
            lResult.Size = new Size(54, 20);
            lResult.TabIndex = 6;
            lResult.Text = "Вывод";
            // 
            // rbPancake
            // 
            rbPancake.AutoSize = true;
            rbPancake.Location = new Point(6, 30);
            rbPancake.Name = "rbPancake";
            rbPancake.Size = new Size(170, 24);
            rbPancake.TabIndex = 7;
            rbPancake.TabStop = true;
            rbPancake.Text = "Сортировка Pancake";
            rbPancake.UseVisualStyleBackColor = true;
            rbPancake.CheckedChanged += rbBubble_CheckedChanged;
            // 
            // rbInsert
            // 
            rbInsert.AutoSize = true;
            rbInsert.Location = new Point(6, 68);
            rbInsert.Name = "rbInsert";
            rbInsert.Size = new Size(153, 24);
            rbInsert.TabIndex = 8;
            rbInsert.TabStop = true;
            rbInsert.Text = "Сортировка Тима";
            rbInsert.UseVisualStyleBackColor = true;
            rbInsert.CheckedChanged += rbInsert_CheckedChanged;
            // 
            // rbSelect
            // 
            rbSelect.AutoSize = true;
            rbSelect.Location = new Point(6, 111);
            rbSelect.Name = "rbSelect";
            rbSelect.Size = new Size(156, 24);
            rbSelect.TabIndex = 9;
            rbSelect.TabStop = true;
            rbSelect.Text = "Сортировка кучей";
            rbSelect.UseVisualStyleBackColor = true;
            rbSelect.CheckedChanged += rbSelect_CheckedChanged;
            // 
            // gpSortTypes
            // 
            gpSortTypes.BackColor = SystemColors.Control;
            gpSortTypes.Controls.Add(heap);
            gpSortTypes.Controls.Add(tim);
            gpSortTypes.Controls.Add(pancake);
            gpSortTypes.Controls.Add(rbPancake);
            gpSortTypes.Controls.Add(rbSelect);
            gpSortTypes.Controls.Add(rbInsert);
            gpSortTypes.Location = new Point(44, 203);
            gpSortTypes.Name = "gpSortTypes";
            gpSortTypes.Size = new Size(296, 162);
            gpSortTypes.TabIndex = 10;
            gpSortTypes.TabStop = false;
            // 
            // heap
            // 
            heap.Location = new Point(217, 107);
            heap.Name = "heap";
            heap.Size = new Size(59, 28);
            heap.TabIndex = 12;
            heap.Text = "?";
            heap.UseVisualStyleBackColor = true;
            heap.Click += heap_Click;
            heap.MouseHover += heap_MouseHover;
            // 
            // tim
            // 
            tim.Location = new Point(217, 68);
            tim.Name = "tim";
            tim.Size = new Size(59, 28);
            tim.TabIndex = 11;
            tim.Text = "?";
            tim.UseVisualStyleBackColor = true;
            tim.Click += tim_Click;
            tim.MouseHover += tim_MouseHover;
            // 
            // pancake
            // 
            pancake.Location = new Point(217, 28);
            pancake.Name = "pancake";
            pancake.Size = new Size(59, 28);
            pancake.TabIndex = 10;
            pancake.Text = "?";
            pancake.UseVisualStyleBackColor = true;
            pancake.Click += pancake_Click;
            pancake.MouseHover += pancake_MouseHover;
            // 
            // lbSortType
            // 
            lbSortType.AutoSize = true;
            lbSortType.Location = new Point(44, 180);
            lbSortType.Name = "lbSortType";
            lbSortType.Size = new Size(132, 20);
            lbSortType.TabIndex = 11;
            lbSortType.Text = "Типы сортировок";
            // 
            // progressBar
            // 
            progressBar.ForeColor = SystemColors.ActiveCaption;
            progressBar.Location = new Point(554, 271);
            progressBar.Name = "progressBar";
            progressBar.Size = new Size(483, 24);
            progressBar.TabIndex = 12;
            progressBar.Visible = false;
            progressBar.Click += progressBar_Click;
            // 
            // lbPercent
            // 
            lbPercent.AutoSize = true;
            lbPercent.Location = new Point(731, 233);
            lbPercent.Name = "lbPercent";
            lbPercent.Size = new Size(137, 20);
            lbPercent.TabIndex = 13;
            lbPercent.Text = "Идет процесс... 0%";
            lbPercent.Visible = false;
            lbPercent.Click += lbPercent_Click;
            // 
            // backgroundSorting
            // 
            backgroundSorting.WorkerReportsProgress = true;
            backgroundSorting.WorkerSupportsCancellation = true;
            backgroundSorting.DoWork += backgroundSorting_DoWork;
            backgroundSorting.ProgressChanged += backgroundSorting_ProgressChanged;
            backgroundSorting.RunWorkerCompleted += backgroundSorting_RunWorkerCompleted;
            // 
            // steps
            // 
            steps.BackColor = Color.CadetBlue;
            steps.Location = new Point(764, 468);
            steps.Name = "steps";
            steps.Size = new Size(94, 60);
            steps.TabIndex = 14;
            steps.Text = "Шаги";
            steps.UseVisualStyleBackColor = false;
            steps.Click += steps_Click;
            // 
            // rtArray
            // 
            rtArray.Cursor = Cursors.No;
            rtArray.Location = new Point(344, 28);
            rtArray.Name = "rtArray";
            rtArray.ReadOnly = true;
            rtArray.Size = new Size(873, 93);
            rtArray.TabIndex = 15;
            rtArray.Text = "";
            // 
            // ttPancake
            // 
            ttPancake.Popup += toolTip1_Popup;
            // 
            // btCompare
            // 
            btCompare.BackColor = Color.CadetBlue;
            btCompare.Location = new Point(44, 393);
            btCompare.Name = "btCompare";
            btCompare.Size = new Size(296, 60);
            btCompare.TabIndex = 16;
            btCompare.Text = "Сравнить";
            btCompare.UseVisualStyleBackColor = false;
            btCompare.Click += btCompare_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1268, 601);
            Controls.Add(btCompare);
            Controls.Add(rtArray);
            Controls.Add(steps);
            Controls.Add(lbPercent);
            Controls.Add(progressBar);
            Controls.Add(lbSortType);
            Controls.Add(gpSortTypes);
            Controls.Add(lResult);
            Controls.Add(rtbResult);
            Controls.Add(bSort);
            Controls.Add(bGenerate);
            Controls.Add(tbArraySize);
            Controls.Add(lArraySize);
            Name = "Form1";
            Text = "Тренажер сортировок";
            Load += Form1_Load_1;
            gpSortTypes.ResumeLayout(false);
            gpSortTypes.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }


        #endregion
        private TextBox tbArraySize;
        private Label lArraySize;
        private Button bGenerate;
        private TextBox tbResult;
        private Label lResult;
        private Button bSort;
        private RichTextBox rtbResult;
        private RadioButton rbPancake;
        private RadioButton rbInsert;
        private RadioButton rbSelect;
        private GroupBox gpSortTypes;
        private Label lbSortType;
        private ProgressBar progressBar;
        private Label lbPercent;
        private System.ComponentModel.BackgroundWorker backgroundSorting;
        private Button steps;
        private RichTextBox rtArray;
        private Button heap;
        private Button tim;
        private Button pancake;
        private ToolTip ttPancake;
        private ToolTip ttTim;
        private ToolTip ttHeap;
        private Button btCompare;
    }
}